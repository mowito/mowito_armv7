/**
 *
 * @file planner_action.h
 * @brief Contains the action server for the planner
 * @author Sourav Agrawal <sourav.agrawal@mowito.in>
 *
 */

#pragma once

#include <mw_core/abstract_classes/abstract_action_base.h>
#include <mw_global_planner/base_planner_execution.h>
#include <actionlib/server/action_server.h>
#include <mw_msgs/GetPathAction.h>

namespace mw_global_planner {
/**
 * @class PlannerAction
 * @brief Contains the defination of the planner action which is based on the abstract action base
 */
class PlannerAction : public mw_core::AbstractActionBase<mw_msgs::GetPathAction,
                                                         mw_global_planner::AbstractPlannerExecution> {
 public:
  typedef boost::shared_ptr<PlannerAction> Ptr;
  /**
   * @brief Constructor to init the action
   */
  PlannerAction(const std::string &name,
                const mw_core::RobotInformation &robot_info);

  //The run method that is run when a new goal is received
  void run(GoalHandle &goal_handle, mw_global_planner::AbstractPlannerExecution &execution);

 protected:
  //Transform a given plan to a global plan
  bool transformPlanToGlobalFrame(std::vector<geometry_msgs::PoseStamped> &plan,
                                  std::vector<geometry_msgs::PoseStamped> &global_plan);
  
  /**
   * The following checks are performed for each pose
   * 1. Number of poses is greater than or equal to number of waypoints
   * 2. Orientation
   *    2.1 if invalid
   *      2.1.1 if final goal, use final goal orientation if valid, else use orientation of previous pose
   *      2.1.2 if waypoint (not final goal), use orientation of waypoint if valid, else use forward derivative
   *      2.1.3 if not waypoint or final goal, use forward derivative
   *    2.2. if valid
   *      2.2.1 if waypoint or final goal with valid orientation, check and copy orientation
   *      2.2.2 if waypoint or final goal has invalid orientation, keep current orientation
   * 
   * 3. Passing all waypoints (checked outside for loop)
   * 
   * @brief Verifies the plan and corrects it if necessary.
   * 
   * @param global_plan the global plan to verify and correct.
   * @param waypoints the waypoints that were used for planning.
   * @param planner_name the name of planner used for planning.
   * 
   * @return true if verification and correction (if needed) succeeded, false otherwise.
   * 
   */ 
  bool verifyAndCorrectPlan(std::vector<geometry_msgs::PoseStamped> &global_plan,
                            std::vector<geometry_msgs::PoseStamped> &waypoints,
                            std::string planner_name);

 private:
  ros::Publisher current_goal_pub_;
  unsigned int path_seq_count_;
};
} // namespace mw_global_planner
