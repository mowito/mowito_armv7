/**
* @file clearcostmap_action.h
* @author Divyanshu Sahu
* @brief Header file for invoking the recovery server incase the robot is stuck
*/

//required header files
#ifndef CLEAR_COSTMAP_ACTION
#define CLEAR_COSTMAP_ACTION

#include <mw_msgs/GetPathAction.h> 
#include <mw_msgs/ExePathAction.h>
#include <actionlib/client/simple_action_client.h>
#include "behaviortree_cpp_v3/bt_factory.h"
#include "behaviortree_cpp_v3/behavior_tree.h"
#include "behaviortree_cpp_v3/condition_node.h"
#include <ros/ros.h>
#include "geometry_msgs/Pose.h"
#include "geometry_msgs/PoseStamped.h"
#include <geometry_msgs/Twist.h>
#include <vector>
#include <executive/mission_executive.h>
#include <fstream>
#include <sstream>
#include <string>
#include <iostream>

using namespace BT;
using namespace std;

//the bt_mowito namespace
namespace bt_mowito
{

	class clearcostmapaction : public AsyncActionNode
		{
  		public:
   			clearcostmapaction(const std::string& name, const NodeConfiguration& config);

   			static BT::PortsList providedPorts() {return {};}
                  //we need no input or output ports for invoking the server.

                  void doneRecoveryCB(const actionlib::SimpleClientGoalState &state,
                                                    const mw_msgs::RecoveryResultConstPtr &result);

                  void activeRecoveryCB(); 

   			BT::NodeStatus tick() override;

   		private:
   			ros::NodeHandle nh10; //nodehandle
   			actionlib::SimpleActionClient<mw_msgs::RecoveryAction> recover; //action server client
                  std::string recover_name; //type of recovery

            };

}
#endif   