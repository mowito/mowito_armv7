/**
* @file reactive_control.h
* @author Divyanshu Sahu
* @brief Header file which creates a custom control node for waypoint mode of BT. The tree will get ticked until all the goals have been reached. This node has to be used with either setwaypointcondition or  
* setroutecondition or setplancondition. These conditions return FAILURE once all the points/paths have been traversed.  
*/

//required header files
#ifndef REACTIVE_CONTROL
#define REACTIVE_CONTROL	

#include <mw_msgs/GetPathAction.h> 
#include <mw_msgs/ExePathAction.h>
#include <mw_msgs/SetString.h>
#include <actionlib/client/simple_action_client.h>
#include "behaviortree_cpp_v3/bt_factory.h"
#include "behaviortree_cpp_v3/behavior_tree.h"
#include <ros/ros.h>
#include "geometry_msgs/Pose.h"
#include "geometry_msgs/PoseStamped.h"
#include <geometry_msgs/Twist.h>
#include <vector>
#include <executive/mission_executive.h>
#include <fstream>
#include <sstream>
#include <string>
#include <iostream>
#include <string>
#include "behaviortree_cpp_v3/control_node.h"  

using namespace BT;
using namespace std;


namespace bt_mowito{

	class ReactiveControl : public BT::ControlNode
	{
	public:

	  	ReactiveControl(const std::string & name, const BT::NodeConfiguration & conf);

		~ReactiveControl() override = default ;

		static BT::PortsList providedPorts()
		{
		    return 
		    {
		      
		    };
		}

		BT::NodeStatus tick() override;
		void halt() override;

	private:
	}; //class ends here

}  // namespace bt_mowito


#endif