/**
 *
* @file replan_recovery_execution.h
 * @brief replan recovery execution class
 * @author Divyanshu Sahu <divyanshu.research@gmail.com>
 *
 */

#ifndef RECOVERY_EXECUTIVE_REPLAN_RECOVERY_EXECUTION_H
#define RECOVERY_EXECUTIVE_REPLAN_RECOVERY_EXECUTION_H

#include <recovery_executive/base_recovery_execution.h>

namespace recovery {

class ReplanRecoveryExecution : public recovery::AbstractRecoveryExecution {

 public:

  ReplanRecoveryExecution();

  ~ReplanRecoveryExecution();
};

}

#endif  // RECOVERY_EXECUTIVE_REPLAN_RECOVERY_EXECUTION_H
