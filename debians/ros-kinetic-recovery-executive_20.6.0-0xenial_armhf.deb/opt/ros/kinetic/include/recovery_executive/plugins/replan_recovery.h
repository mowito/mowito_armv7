/**
 *
 * @file replan_recovery.h
 * @brief replan recovery class
 * @author Divyanshu Sahu <divyanshu.research@gmail.com>
 *
 */

#ifndef RECOVERY_EXECUTIVE_REPLAN_RECOVERY_H
#define RECOVERY_EXECUTIVE_REPLAN_RECOVERY_H

#include <std_srvs/Trigger.h>
#include <ros/ros.h>
#include <recovery_executive/base_recovery.h>
#include <ros/ros.h>
#include <vector>
#include <std_srvs/Empty.h>


namespace recovery {
/**
 * @class ReplanRecovery
 * @brief A recovery behavior that makes the executive replan its current goal.
 */
class ReplanRecovery : public recovery::AbstractRecovery {
public:
  /**
   * @brief  Constructor, make sure to call initialize in addition to actually initialize the object
   * @param
   * @return
   */
  ReplanRecovery();

  /**
   * @brief  Initialization function for the Replan recovery behavior
   * @param name Namespace used in initialization
   * @param tf (unused)
   */
  void initialize(const std::string &name, const TFPtr &tf_listener_ptr) override;

  /**
   * @brief  Run the Replan recovery behavior.
   */
  uint32_t runBehavior(std::string& message) override;

  bool cancel() override;

private:

  ros::ServiceClient replan_srv_client_;
  bool initialized_;
};
};

#endif //RECOVERY_EXECUTIVE_REPLAN_RECOVERY_H
