/**
* @file isstuck_condition_action.h
* @author Divyanshu Sahu, Ashwin Gururaj
* @brief Header file for checking if the robot is stuck or not by using the robots odometry
*/

//required header files
#ifndef IS_STUCK_CONDITION
#define IS_STUCK_CONDITION

#include <mw_msgs/GetPathAction.h> 
#include <mw_msgs/ExePathAction.h>
#include <actionlib/client/simple_action_client.h>
#include <nav_msgs/Odometry.h>
#include "behaviortree_cpp_v3/bt_factory.h"
#include "behaviortree_cpp_v3/behavior_tree.h"
#include "behaviortree_cpp_v3/condition_node.h"
#include <ros/ros.h>
#include "geometry_msgs/Pose.h"
#include "geometry_msgs/PoseStamped.h"
#include <geometry_msgs/Twist.h>
#include <vector>
#include <executive/mission_executive.h>
#include <fstream>
#include <sstream>
#include <string>
#include <iostream>

using namespace BT;
using namespace std;

//the bt_mowito namespace
namespace bt_mowito{

	//isStuckCondition condition class
	class isStuckCondition : public BT::ConditionNode
	{
		public:
	  		isStuckCondition(const std::string & condition_name,
	    							  const BT::NodeConfiguration & conf);

	    		static BT::PortsList providedPorts() {return {InputPort<int>("start_bt_flag_"), OutputPort<int>("start_flag_out")};}
	    		/*
	            * brief:The method for initialising the required input and output ports for the BLACKBOARD
	            * Input Port: A flag to know if the robot had been in hybernation as it had no goals to pursue 
	            * Output port: The input flag is taken in processed, changed and put on the BLACKBOARD 
	            */
			
	    		void callback(const nav_msgs::Odometry::ConstPtr &msg);
	    		//callback to store the odometry data
			bool is_robot_moved_enough(nav_msgs::Odometry odom);
			//method to check the robot's movement
			
	    		BT::NodeStatus tick() override;

    		private:
    			ros::NodeHandle nh3; //nodehandle
			bool is_baseline_set; //flag
    			std::deque<nav_msgs::Odometry> odom_history_; //odom data collection queue
    			std::deque<nav_msgs::Odometry>::size_type odom_history_size_; //sizw of the odom queue
    			ros::Subscriber odom_sub; //subscriber to the odom topic
			nav_msgs::Odometry baseline; //odom object for comparing the data
			ros::Time baseline_time, flag_zero_time, flag_one_time; // ros time elements
	}; 

}
#endif 
