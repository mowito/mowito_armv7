/**
* @file initialize_action.h
* @author Divyanshu Sahu
* @brief Header file for iinitiallising any flags or logic for debugging purposes
*/

//required header files
#ifndef  INITIALIZE_ACTION
#define INITIALIZE_ACTION


#include <mw_msgs/GetPathAction.h> 
#include <mw_msgs/ExePathAction.h>
#include <mw_msgs/SetString.h>
#include <actionlib/client/simple_action_client.h>
#include "behaviortree_cpp_v3/bt_factory.h"
#include "behaviortree_cpp_v3/behavior_tree.h"
#include <ros/ros.h>
#include "geometry_msgs/Pose.h"
#include "geometry_msgs/PoseStamped.h"
#include <geometry_msgs/Twist.h>
#include <vector>
#include <executive/mission_executive.h>
#include <fstream>
#include <sstream>
#include <string>
#include <iostream>

using namespace BT;
using namespace std;


namespace bt_mowito{


	class initializeaction : public SyncActionNode
	{
	  public:
	    initializeaction(const std::string& name, const NodeConfiguration& config);

	    static PortsList providedPorts()
	    {
	        return {OutputPort<bool>("set_flag")};
	    }

	    NodeStatus tick() override;
	    
	  private:
	    int set_blackboard_flag;
	};
}
#endif   