// Auto-generated. Do not edit!

// (in-package mw_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Duty = require('../msg/Duty.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class SetDutyRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.duty = null;
    }
    else {
      if (initObj.hasOwnProperty('duty')) {
        this.duty = initObj.duty
      }
      else {
        this.duty = new Duty();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetDutyRequest
    // Serialize message field [duty]
    bufferOffset = Duty.serialize(obj.duty, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetDutyRequest
    let len;
    let data = new SetDutyRequest(null);
    // Deserialize message field [duty]
    data.duty = Duty.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += Duty.getMessageSize(object.duty);
    return length;
  }

  static datatype() {
    // Returns string type for a service object
    return 'mw_msgs/SetDutyRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9e36845a81d83dc5b4b898dfb4dde191';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    mw_msgs/Duty duty
    
    ================================================================================
    MSG: mw_msgs/Duty
    # Unique ID for each duty
    uint32 id
    
    # Total number of tasks
    uint64 total_tasks
    
    # List of tasks
    mw_msgs/Task[] tasks
    
    # Is loop enabled
    bool loop_enabled
    ================================================================================
    MSG: mw_msgs/Task
    # Unique ID for each task
    uint32 id
    
    # Route field when type is ROUTE
    mw_msgs/Route route
    
    # Duration (in seconds) to run this task (when type is not ROUTE)
    float32 duration
    
    # End behaviour, ie, time to wait after this task ends and before starting the next task
    float32 end_behaviour
    
    # Type of task
    uint8 type
    
    # Enumeration for different types
    uint8 ROUTE=0
    uint8 WAIT=1
    
    # Task status
    uint8 status
    
    # Enumeration for different task states
    uint8 NOT_STARTED=0
    uint8 WIP=1
    uint8 COMPLETED=2
    ================================================================================
    MSG: mw_msgs/Route
    # Unique ID for each different route
    uint32 id
    
    # Header
    std_msgs/Header header
    
    # Array of waypoints
    geometry_msgs/PoseStamped[] waypoints
    
    # Route status
    uint8 status
    
    # Enumeration for different route states
    uint8 NOT_STARTED=0
    uint8 WIP=1
    uint8 COMPLETED=2
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/PoseStamped
    # A Pose with reference coordinate frame and timestamp
    Header header
    Pose pose
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetDutyRequest(null);
    if (msg.duty !== undefined) {
      resolved.duty = Duty.Resolve(msg.duty)
    }
    else {
      resolved.duty = new Duty()
    }

    return resolved;
    }
};

class SetDutyResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetDutyResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetDutyResponse
    let len;
    let data = new SetDutyResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'mw_msgs/SetDutyResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '358e233cde0c8a8bcfea4ce193f8fc15';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetDutyResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    return resolved;
    }
};

module.exports = {
  Request: SetDutyRequest,
  Response: SetDutyResponse,
  md5sum() { return 'fbe01792339d434c95654724139e2c83'; },
  datatype() { return 'mw_msgs/SetDuty'; }
};
