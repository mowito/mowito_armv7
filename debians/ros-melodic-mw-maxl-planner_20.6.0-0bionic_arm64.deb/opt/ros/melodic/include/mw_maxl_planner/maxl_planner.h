/**
 *
 * @file maxl_planner.h
 * @brief The MAximum Liklihood Planner class.
 * @author Puru Rastogi <puru@mowito.in>
 *
 */

#ifndef MAXL_PLANNER_H
#define MAXL_PLANNER_H

// C++ classes
#include <math.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>

// Mowito Nav Stack base class
// #include <controller_executive/base_controller.h>

// ROS
#include <ros/ros.h>

// PCL header
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/kdtree/kdtree_flann.h>

#include <pcl_ros/point_cloud.h>
#include <pcl_ros/transforms.h>

// ROS Message
#include <std_msgs/Bool.h>
#include <std_msgs/Float32.h>
#include <nav_msgs/Path.h>
#include <nav_msgs/Odometry.h>

#include <geometry_msgs/Pose2D.h>
#include <geometry_msgs/PointStamped.h>
#include <geometry_msgs/PolygonStamped.h>
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/Joy.h>
#include <sensor_msgs/LaserScan.h>

#include <geometry_msgs/Twist.h>

// TF
#include <tf/tf.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <tf/transform_listener.h>
#include <tf2/convert.h>
#include <tf2_ros/buffer.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <mw_core/utility_functions.h>

// Others
#include <laser_geometry/laser_geometry.h>
#include <message_filters/subscriber.h>
#include <message_filters/synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>

#include <nav_msgs/Path.h>

// dynamic reconfigure
#include <dynamic_reconfigure/server.h>

// #define M_PI 3.1415926

namespace mw_maxl_planner
{

  /**
    * @class MaxlPlanner
    * @brief Implements both controller::AbstractController
    */
  class MaxlPlanner
  {
    public:
      /**
        * @brief Default constructor of the teb plugin
        */
      MaxlPlanner(std::string pathFolder,
                  bool autonomyMode,
                  std::string map_frame,
                  std::string robot_frame,
                  std::string velodyne_frame,
                  std::string laser_frame,
                  // pure pursuit param
                  bool lookahead_goal_on_path,
                  double min_lookahead,
                  double max_lookahead,
                  int closest_point_index_search,
                  double max_y_deviation,
                  double min_radius,
                  double max_radius,
                  double max_omega_radius,
                  double max_path_dev,
                  double lookahead_point_distance,
                  // robot related param
                  double vehicleLength,
                  double vehicleWidth,
                  double sensorOffsetX,
                  double sensorOffsetY,
                  // for controller
                  double lookAheadDis,
                  double maxSpeed,
                  double maxAccel,
                  double dir_weight,
                  double dir_threshold
                  );

      /**
        * @brief  Destructor of the plugin
        */
       ~MaxlPlanner();

    public:
      // callbacks for subscriber mentioned in maxl_planner_mw
      void odometryHandler(const nav_msgs::Odometry::ConstPtr& odom);
      void velodynScanHandler(const sensor_msgs::PointCloud2::ConstPtr& scanIn);
      void laserScanHandler(const sensor_msgs::LaserScan::ConstPtr& scanIn);
      void globalPathHandler(const std::vector<geometry_msgs::PoseStamped>& path);
      void computePath();
      void clearPlan();
      void computeVelocity();
      void getCmdVel(geometry_msgs::Twist &cmd_vel);
      bool isGoalReached(double dist_tolerance, double angle_tolerance);

    protected:
      double calculateXYDeviation(const geometry_msgs::Pose2D &pose1, const geometry_msgs::Pose2D &pose2);
      geometry_msgs::Pose2D getIntersection(bool is_vert_1, double m_1, double c_1,
                                            bool is_vert_2, double m_2, double c_2);
      double getRadiusOfCurvature(const geometry_msgs::Pose2D pose1, const geometry_msgs::Pose2D pose2);
      double getRadiusOfCurvatureOfGoalPoints();
      double improveLookahead(double lookahead, double path_deviation);
      int findClosestPose();
      double getLookahead(const double &_curv);
      int getTargetPoseIndex(const double &lookahead);
      void getLookAheadGoal();
      int readPlyHeader(FILE *filePtr);
      void readStartPaths();
      void readPaths();
      void readPathList();
      void readCorrespondences();

    private:
      std::string pathFolder_;
      bool autonomyMode_ = false;
      std::string map_frame_;
      std::string robot_frame_;
      std::string velodyne_frame_;
      std::string laser_frame_;

      // Robot param variables
      double vehicleLength_ = 0.22;
      double vehicleWidth_ = 0.22;
      double sensorOffsetX_ = 0;
      double sensorOffsetY_ = 0;
      bool twoWayDrive_ = false;
      double laserVoxelSize_ = 0.05;

      bool checkObstacle_ = true;
      bool checkRotObstacle_ = true;//false;
      double adjacentRange_ = 3.5;
      double speedToRangeScale_ = 4.5;
      double obstacleHeightThre_ = 0.2;
      double groundHeightThre_ = 0.1;
      double costHeightThre_ = 0.1;
      double costScore_ = 0.02;
      int pointPerPathThre_ = 1;
      double lowerBoundZ_ = -0.25;
      double upperBoundZ_ = 0.5;
      double dirWeight_ = 0.02;
      double dirThre_ = 120;//90.0;
      double pathScale_ = 1.0;
      double minPathScale_ = 0.75;
      double pathScaleStep_ = 0.25;
      double minPathRange_ = 1.0;
      double pathRangeStep_ = 0.5;
      bool pathCrop_ = true;


      double autonomySpeed_ = 1.0;
      double goalX_,goalY_;


      // Pure pursuit params variables
      bool lookahead_goal_on_path_ = false;
      int closest_pose_idx_;
      double min_lookahead_;
      double max_lookahead_;
      int closest_point_index_search_;
      double max_y_deviation_;
      double min_radius_;
      double max_radius_;
      double max_omega_radius_;
      double max_path_dev_;
      double lookahead_point_distance_ = 0.03;

      double terrainVoxelSize = 0.2;
      bool useTerrainAnalysis = false;
      
      const int laserCloudStackNum = 1;
      int laserCloudCount = 0;
      
      
      float joySpeed = 0;
      float joyDir = 0;
      
      int pathNum = 27;//343;
      int groupNum = 3;//7;
      const int gridVoxelNumX = 161;
      const int gridVoxelNumY = 451;
      const int gridVoxelNum = gridVoxelNumX * gridVoxelNumY;
      
      float gridVoxelSize = 0.02;
      float searchRadius = 0.45;
      float gridVoxelOffsetX = 3.2;
      float gridVoxelOffsetY = 4.5;

      
      ros::Publisher *pubScanPointer = NULL;

      tf::TransformListener listener;
      // tf2_ros::Buffer tf_;
      std::shared_ptr<tf2_ros::Buffer> tf_;
      
      pcl::PointCloud<pcl::PointXYZI>::Ptr scanData = pcl::PointCloud<pcl::PointXYZI>::Ptr(new pcl::PointCloud<pcl::PointXYZI>());
      
      pcl::PointCloud<pcl::PointXYZI>::Ptr laserCloud = pcl::PointCloud<pcl::PointXYZI>::Ptr(new pcl::PointCloud<pcl::PointXYZI>());
      pcl::PointCloud<pcl::PointXYZI>::Ptr laserCloudCrop = pcl::PointCloud<pcl::PointXYZI>::Ptr(new pcl::PointCloud<pcl::PointXYZI>());
      pcl::PointCloud<pcl::PointXYZI>::Ptr laserCloudDwz = pcl::PointCloud<pcl::PointXYZI>::Ptr(new pcl::PointCloud<pcl::PointXYZI>());
      
      std::vector<pcl::PointCloud<pcl::PointXYZI>::Ptr> laserCloudStack = std::vector<pcl::PointCloud<pcl::PointXYZI>::Ptr>(laserCloudStackNum);
      pcl::PointCloud<pcl::PointXYZI>::Ptr plannerCloud = pcl::PointCloud<pcl::PointXYZI>::Ptr(new pcl::PointCloud<pcl::PointXYZI>());
      pcl::PointCloud<pcl::PointXYZI>::Ptr plannerCloudCrop = pcl::PointCloud<pcl::PointXYZI>::Ptr(new pcl::PointCloud<pcl::PointXYZI>());
      pcl::PointCloud<pcl::PointXYZI>::Ptr boundaryCloud = pcl::PointCloud<pcl::PointXYZI>::Ptr(new pcl::PointCloud<pcl::PointXYZI>());
      std::vector<pcl::PointCloud<pcl::PointXYZ>::Ptr> startPaths = std::vector<pcl::PointCloud<pcl::PointXYZ>::Ptr> (groupNum);
      std::vector<pcl::PointCloud<pcl::PointXYZI>::Ptr> paths = std::vector<pcl::PointCloud<pcl::PointXYZI>::Ptr> (pathNum);
      pcl::PointCloud<pcl::PointXYZI>::Ptr freePaths = pcl::PointCloud<pcl::PointXYZI>::Ptr(new pcl::PointCloud<pcl::PointXYZI>());
      
      std::vector<int>   pathList = std::vector<int>(pathNum, 0);
      std::vector<double> endDirPathList = std::vector<double>(pathNum, 0);
      std::vector<int>   clearPathList = std::vector<int>(36 * pathNum, 0);
      std::vector<double> pathPenaltyList = std::vector<double>(36 * pathNum, 0);
      std::vector<double> clearPathPerGroupScore = std::vector<double>(36 * groupNum, 0);
      std::vector<std::vector<int>> correspondences = std::vector<std::vector<int>>(gridVoxelNum); //= std::vector<int>(gridVoxelNum);
      
      bool newLaserCloud = false;
      
      double odomTime;
      double joyTime;
      
      float vehicleRoll, vehiclePitch, vehicleYaw;
      float vehicleX, vehicleY, vehicleZ;

      float vehicleXRec, vehicleYRec, vehicleZRec, vehicleRollRec, vehiclePitchRec, vehicleYawRec;
      int pathPointID = 0;
      
      pcl::VoxelGrid<pcl::PointXYZI> laserDwzFilter, terrainDwzFilter;
      
      
      std::vector<geometry_msgs::Pose2D> global_path_;
      geometry_msgs::Pose2D current_pose_;

      ros::Publisher pubLookaheadGoal, pubFreePaths, pubScan, pubPath, pubCroppedScan, pubRelativeGoal;
     

      geometry_msgs::PointStamped lookahead_goal;

      ros::NodeHandle nh_;

      // Laser related
      laser_geometry::LaserProjection projector_;

      nav_msgs::Path path;
      
      // for controller
      double lookAheadDis_ = 0.5;
      double yawRateGain = 3.5;
      double stopYawRateGain = 3.5;
      double maxYawRate = 0.8;
      double maxSpeed_ = 0.4;
      double maxAccel_ = 0.5;
      double switchTimeThre = 1.0;
      double dirDiffThre = 0.1;
      double stopDisThre = 0.4;
      double slowDwnDisThre = 0.5;
      double vehicleYawRate = 0;
      double vehicleSpeed = 0;
      bool navFwd = true;
      double switchTime = 0;

      geometry_msgs::Twist cmd_vel;

  };

} // end namespace maxl_planner

#endif // MAXL_PLANNER_H_