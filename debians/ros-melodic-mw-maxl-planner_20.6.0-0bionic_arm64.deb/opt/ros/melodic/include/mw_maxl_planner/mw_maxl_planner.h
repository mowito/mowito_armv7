
#ifndef MW_MAXL_PLANNER_H_
#define MW_MAXL_PLANNER_H_

// C++ Headers
#include <string.h>

// ROS Headers
#include <ros/ros.h>
#include <dynamic_reconfigure/server.h>
#include <maxl_planner.h>

#include <controller_executive/base_controller.h>


namespace mw_maxl_planner {
/**
 * @class MaxlPlannerROS
 * @brief A ROS wrapper for the trajectory controller that queries the param server to construct a controller
 */
class MwMaxlPlanner : public controller::AbstractController {
 public:
  /**
   * @brief  Default constructor for the ros wrapper
   */
  MwMaxlPlanner();

  /**
   * @brief  Constructs the ros wrapper
   * @param name The name to give this instance of the trajectory planner
   * @param tf A pointer to a transform listener
   * @param costmap The cost map to use for assigning costs to trajectories
   */
  void initialize(const std::string &name, const TFPtr &tf_listener_ptr);

  void odometryHandler(const nav_msgs::Odometry::ConstPtr& odom);
  void velodynScanHandler(const sensor_msgs::PointCloud2::ConstPtr& scanIn);
  void laserScanHandler(const sensor_msgs::LaserScan::ConstPtr& scanIn);


  /**
   * @brief  Destructor for the wrapper
   */
  ~MwMaxlPlanner();

  // ###################################
  // #  Abstract Controller Functions  #
  // ###################################

  unsigned int computeVelocityCommands(const geometry_msgs::PoseStamped &pose,
                                       const geometry_msgs::TwistStamped &velocity,
                                       geometry_msgs::TwistStamped &cmd_vel,
                                       std::string &message) override;

  /**
   * @brief Check if the goal pose has been achieved by the local planner
   * @param angle_tolerance The angle tolerance in which the current pose will be partly accepted as reached goal
   * @param dist_tolerance The distance tolerance in which the current pose will be partly accepted as reached goal
   * @return True if achieved, false otherwise
   */
  bool isGoalReached(double dist_tolerance, double angle_tolerance) override;

  /**
   * @brief Set the plan that the local planner is following
   * @param plan The plan to pass to the local planner
   * @return True if the plan was updated successfully, false otherwise
   */
  bool setPlan(const std::vector<geometry_msgs::PoseStamped> &plan) override;

  /**
   * @brief Requests the planner to cancel, e.g. if it takes too much time.
   * @return True if a cancel has been successfully requested, false if not implemented.
   */
  bool cancel() override;

  void reset() override;

  // ##################################
  // #  Trajectory Planner Functions  #
  // ##################################

  bool isInitialized() {
    return initialized_;
  }

  /** @brief Return the inner TrajectoryPlanner object.  Only valid after initialize(). 
  TrajectoryPlanner *getPlanner() const { 
    return tc_; 
  }
  */

 private:
  /**
   * @brief Callback to update the local planner's parameters based on dynamic reconfigure
   */
  // void reconfigureCB(controller_executive::TrajectoryPlannerConfig &config, uint32_t level);

  int pathPointID = 0;
  int pathInit = false;
  bool initialized_ = false;
  bool navFwd = true;
  bool reached_goal_;
  MaxlPlanner *maxl_planner_;
  // dynamic_reconfigure::Server<controller_executive::TrajectoryPlannerConfig> *dsrv_;

  // Publisher and subscriber
  ros::Subscriber subScan, subOdometry; //, subGlobalPath;
  ros::Publisher pubPath, pubLookaheadGoal, pubScan, pubFreePaths;


  bool use_laser;
  bool plot_path;
  std::string odomTopic;
  std::string velodyneTopic;
  std::string scanTopic;
  
  std::string pathFolder;
  bool autonomyMode;
  std::string map_frame;
  std::string robot_frame;
  std::string velodyne_frame;
  std::string laser_frame;

  // pure pursuit param
  bool   lookahead_goal_on_path;
  double min_lookahead;
  double max_lookahead;
  int    closest_point_index_search;
  double max_y_deviation;
  double min_radius;
  double max_radius;
  double max_omega_radius;
  double max_path_dev;
  double lookahead_point_distance;

  // robot related param
  double vehicleLength;
  double vehicleWidth;
  double sensorOffsetX;
  double sensorOffsetY;

  // for controller
  double lookAheadDis;
  double maxSpeed;
  double maxAccel;
  double dir_weight;
  double dir_threshold;

  //for the high accuracy xy goal
  double high_accuracy_multiplier;
};
}
#endif
