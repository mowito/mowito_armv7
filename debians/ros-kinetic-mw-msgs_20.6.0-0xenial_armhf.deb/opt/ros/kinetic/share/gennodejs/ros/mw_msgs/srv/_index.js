
"use strict";

let SetCost = require('./SetCost.js')
let GetRoute = require('./GetRoute.js')
let SetDuty = require('./SetDuty.js')
let GetPose = require('./GetPose.js')
let SetString = require('./SetString.js')
let GetTask = require('./GetTask.js')
let SetNodeState = require('./SetNodeState.js')
let GetCircumscribedRadius = require('./GetCircumscribedRadius.js')
let SetTask = require('./SetTask.js')
let GetSbplPlan = require('./GetSbplPlan.js')
let LoadRouteFromFile = require('./LoadRouteFromFile.js')
let GetString = require('./GetString.js')
let SetRobotFootprint = require('./SetRobotFootprint.js')
let ComputeCircumscribedCost = require('./ComputeCircumscribedCost.js')
let GetRouteStatus = require('./GetRouteStatus.js')
let LoadDutyFromFile = require('./LoadDutyFromFile.js')
let SetPlan = require('./SetPlan.js')
let GetDuty = require('./GetDuty.js')
let GetDouble = require('./GetDouble.js')
let LoadTaskFromFile = require('./LoadTaskFromFile.js')
let GetTaskStatus = require('./GetTaskStatus.js')
let SetMode = require('./SetMode.js')
let GetPlan = require('./GetPlan.js')
let SetRoute = require('./SetRoute.js')

module.exports = {
  SetCost: SetCost,
  GetRoute: GetRoute,
  SetDuty: SetDuty,
  GetPose: GetPose,
  SetString: SetString,
  GetTask: GetTask,
  SetNodeState: SetNodeState,
  GetCircumscribedRadius: GetCircumscribedRadius,
  SetTask: SetTask,
  GetSbplPlan: GetSbplPlan,
  LoadRouteFromFile: LoadRouteFromFile,
  GetString: GetString,
  SetRobotFootprint: SetRobotFootprint,
  ComputeCircumscribedCost: ComputeCircumscribedCost,
  GetRouteStatus: GetRouteStatus,
  LoadDutyFromFile: LoadDutyFromFile,
  SetPlan: SetPlan,
  GetDuty: GetDuty,
  GetDouble: GetDouble,
  LoadTaskFromFile: LoadTaskFromFile,
  GetTaskStatus: GetTaskStatus,
  SetMode: SetMode,
  GetPlan: GetPlan,
  SetRoute: SetRoute,
};
