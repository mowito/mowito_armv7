// Auto-generated. Do not edit!

// (in-package mw_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class SetRobotFootprintRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.footprint = null;
    }
    else {
      if (initObj.hasOwnProperty('footprint')) {
        this.footprint = initObj.footprint
      }
      else {
        this.footprint = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetRobotFootprintRequest
    // Serialize message field [footprint]
    // Serialize the length for message field [footprint]
    bufferOffset = _serializer.uint32(obj.footprint.length, buffer, bufferOffset);
    obj.footprint.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Point.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetRobotFootprintRequest
    let len;
    let data = new SetRobotFootprintRequest(null);
    // Deserialize message field [footprint]
    // Deserialize array length for message field [footprint]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.footprint = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.footprint[i] = geometry_msgs.msg.Point.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 24 * object.footprint.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'mw_msgs/SetRobotFootprintRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3e00cf11c06775afb0e06681e0f9f229';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    geometry_msgs/Point[] footprint
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetRobotFootprintRequest(null);
    if (msg.footprint !== undefined) {
      resolved.footprint = new Array(msg.footprint.length);
      for (let i = 0; i < resolved.footprint.length; ++i) {
        resolved.footprint[i] = geometry_msgs.msg.Point.Resolve(msg.footprint[i]);
      }
    }
    else {
      resolved.footprint = []
    }

    return resolved;
    }
};

class SetRobotFootprintResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetRobotFootprintResponse
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetRobotFootprintResponse
    let len;
    let data = new SetRobotFootprintResponse(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'mw_msgs/SetRobotFootprintResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd41d8cd98f00b204e9800998ecf8427e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetRobotFootprintResponse(null);
    return resolved;
    }
};

module.exports = {
  Request: SetRobotFootprintRequest,
  Response: SetRobotFootprintResponse,
  md5sum() { return '3e00cf11c06775afb0e06681e0f9f229'; },
  datatype() { return 'mw_msgs/SetRobotFootprint'; }
};
