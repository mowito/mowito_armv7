// Auto-generated. Do not edit!

// (in-package mw_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class mission_status {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.machine_state = null;
      this.controller_type = null;
      this.global_planner_type = null;
    }
    else {
      if (initObj.hasOwnProperty('machine_state')) {
        this.machine_state = initObj.machine_state
      }
      else {
        this.machine_state = '';
      }
      if (initObj.hasOwnProperty('controller_type')) {
        this.controller_type = initObj.controller_type
      }
      else {
        this.controller_type = '';
      }
      if (initObj.hasOwnProperty('global_planner_type')) {
        this.global_planner_type = initObj.global_planner_type
      }
      else {
        this.global_planner_type = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type mission_status
    // Serialize message field [machine_state]
    bufferOffset = _serializer.string(obj.machine_state, buffer, bufferOffset);
    // Serialize message field [controller_type]
    bufferOffset = _serializer.string(obj.controller_type, buffer, bufferOffset);
    // Serialize message field [global_planner_type]
    bufferOffset = _serializer.string(obj.global_planner_type, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type mission_status
    let len;
    let data = new mission_status(null);
    // Deserialize message field [machine_state]
    data.machine_state = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [controller_type]
    data.controller_type = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [global_planner_type]
    data.global_planner_type = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.machine_state.length;
    length += object.controller_type.length;
    length += object.global_planner_type.length;
    return length + 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mw_msgs/mission_status';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '895e9fe1746b68ba4df2e225f5811bcd';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # status indicating machine state (PLANNING/CONTROLLING/RECOVERING/WAITING)
    string machine_state
    
    # status indicating name of the controller type being used
    string controller_type
    
    # status indicating name of the global planner type being used
    string global_planner_type
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new mission_status(null);
    if (msg.machine_state !== undefined) {
      resolved.machine_state = msg.machine_state;
    }
    else {
      resolved.machine_state = ''
    }

    if (msg.controller_type !== undefined) {
      resolved.controller_type = msg.controller_type;
    }
    else {
      resolved.controller_type = ''
    }

    if (msg.global_planner_type !== undefined) {
      resolved.global_planner_type = msg.global_planner_type;
    }
    else {
      resolved.global_planner_type = ''
    }

    return resolved;
    }
};

module.exports = mission_status;
